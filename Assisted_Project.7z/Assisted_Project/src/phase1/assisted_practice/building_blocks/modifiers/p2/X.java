package phase1.assisted_practice.building_blocks.modifiers.p2;

public class X {
	private int intVar = 145;
	long longVar = 4657;
	protected float floatVar = 178.56f;
	public char charVar='f';

}
